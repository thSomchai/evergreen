Web client (React + PixiJS)
