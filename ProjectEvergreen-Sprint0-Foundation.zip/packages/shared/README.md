Shared types/utilities
