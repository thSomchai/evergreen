Engine core
